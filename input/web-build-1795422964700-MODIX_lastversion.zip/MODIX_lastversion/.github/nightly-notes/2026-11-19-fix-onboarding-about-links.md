## Fixed
- Fixed the welcome setup screen appearing again after it had already been completed.
- Updated the About page links to show the developer channel and contact options, and removed the website and Reddit labels.
