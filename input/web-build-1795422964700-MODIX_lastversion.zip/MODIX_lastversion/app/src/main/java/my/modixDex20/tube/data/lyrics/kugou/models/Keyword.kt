//==================================================================================================
//This implementation was based on metrolist's (https://github.com/MetrolistGroup/Metrolist)
//==================================================================================================

package my.modixDex20.tube.data.lyrics.kugou.models

data class Keyword(val title: String, val artist: String, val album: String? = null)
