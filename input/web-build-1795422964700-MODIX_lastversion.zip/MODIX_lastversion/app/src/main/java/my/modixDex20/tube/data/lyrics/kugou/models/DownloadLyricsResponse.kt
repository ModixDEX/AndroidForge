//==================================================================================================
//This implementation was based on metrolist's (https://github.com/MetrolistGroup/Metrolist)
//==================================================================================================

package my.modixDex20.tube.data.lyrics.kugou.models

data class DownloadLyricsResponse(
    val content: String = ""
)
