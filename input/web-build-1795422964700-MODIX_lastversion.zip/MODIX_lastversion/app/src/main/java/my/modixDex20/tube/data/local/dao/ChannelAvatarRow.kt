package my.modixDex20.tube.data.local.dao

/** A channel's avatar as a cached row recorded it. */
data class ChannelAvatarRow(
    val channelId: String,
    val channelThumbnailUrl: String,
)
