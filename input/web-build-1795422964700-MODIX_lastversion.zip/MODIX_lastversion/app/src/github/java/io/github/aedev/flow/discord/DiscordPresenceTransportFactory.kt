package my.modixDex20.tube.discord

import android.content.Context
import okhttp3.OkHttpClient

interface DiscordPresenceTransportFactory {
    fun create(
        context: Context,
        okHttpClient: OkHttpClient,
        tokenStore: DiscordTokenStore,
    ): DiscordPresenceTransport
}
