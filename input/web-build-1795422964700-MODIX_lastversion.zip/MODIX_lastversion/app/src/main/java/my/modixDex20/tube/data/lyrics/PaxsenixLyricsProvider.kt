// ==================================================================================================
// This implementation was based on metrolist's (https://github.com/MetrolistGroup/Metrolist)
// ==================================================================================================

package my.modixDex20.tube.data.lyrics

import my.modixDex20.tube.data.lyrics.paxsenix.Paxsenix
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient

class PaxsenixLyricsProvider(
    client: OkHttpClient,
) : LyricsProvider {
    override val name = "Paxsenix"

    private val paxsenix = Paxsenix(client)

    override suspend fun getLyrics(
        id: String,
        title: String,
        artist: String,
        duration: Int,
        album: String?,
    ): Result<List<LyricsEntry>> =
        withContext(Dispatchers.IO) {
            runCatching {
                val lrc = paxsenix.getLyrics(title, artist, duration, album).getOrThrow()
                LyricsUtils.parseLyrics(lrc)
            }
        }
}
